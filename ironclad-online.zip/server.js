// Ironclad Duel - online relay server.
// Serves the game page and pairs two players in a room; it only forwards messages between them.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const PAGE = path.join(__dirname, 'public', 'index.html');

function page() {
  // Read on every request so you can drop in a newer index.html without restarting.
  const html = fs.readFileSync(PAGE, 'utf8');
  const head = '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">' +
    '<script>window.IRONCLAD_SERVER=1</script>';
  return html.startsWith('<!doctype') ? html.replace(/<head>/i, '<head>' + head) : '<!doctype html><html><head>' + head + '</head><body>' + html + '</body></html>';
}

const server = http.createServer((req, res) => {
  if (req.url === '/' || req.url.startsWith('/?') || req.url === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
    res.end(page());
  } else if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('ok');
  } else {
    res.writeHead(404); res.end('Not found');
  }
});

const wss = new WebSocketServer({ server, maxPayload: 256 * 1024 });
const rooms = new Map(); // code -> { host, guest }

function newCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  let c;
  do { c = Array.from({ length: 4 }, () => A[Math.floor(Math.random() * A.length)]).join(''); } while (rooms.has(c));
  return c;
}
function send(ws, obj) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj)); }

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (data) => {
    const text = data.toString();
    let msg;
    try { msg = JSON.parse(text); } catch { return; }

    if (msg.t === 'create') {
      const code = newCode();
      rooms.set(code, { host: ws, guest: null });
      ws.room = code; ws.role = 'host';
      send(ws, { t: 'created', code });
      return;
    }
    if (msg.t === 'join') {
      const code = String(msg.code || '').toUpperCase();
      const room = rooms.get(code);
      if (!room) return send(ws, { t: 'error', msg: 'No room with that code.' });
      if (room.guest) return send(ws, { t: 'error', msg: 'That room already has two knights.' });
      room.guest = ws; ws.room = code; ws.role = 'guest';
      send(ws, { t: 'joined', code });
      send(room.host, { t: 'peer' });
      return;
    }
    // everything else is passed straight to the other player
    const room = rooms.get(ws.room);
    if (!room) return;
    const other = ws.role === 'host' ? room.guest : room.host;
    if (other && other.readyState === 1) other.send(text);
  });

  ws.on('close', () => {
    const room = rooms.get(ws.room);
    if (!room) return;
    const other = ws.role === 'host' ? room.guest : room.host;
    send(other, { t: 'left' });
    if (ws.role === 'host') { rooms.delete(ws.room); if (other) other.close(); }
    else room.guest = null;
  });
});

// drop dead connections
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
}, 30000);

server.listen(PORT, () => {
  console.log(`Ironclad Duel is running.`);
  console.log(`Open http://localhost:${PORT} in your browser.`);
});
