@echo off
title Ironclad Duel server
cd /d "%~dp0"
if not exist "Ironclad Duel.lnk" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($p in @('%~dp0Ironclad Duel.lnk', [Environment]::GetFolderPath('Desktop')+'\Ironclad Duel.lnk')){ $s=$w.CreateShortcut($p); $s.TargetPath='%~dp0ironclad.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0ironclad.ico,0'; $s.Description='Ironclad Duel'; $s.Save() }" >nul 2>nul
  if not exist desktop.ini (
    (echo [.ShellClassInfo]& echo IconResource=ironclad.ico,0)>desktop.ini
    attrib +s +h desktop.ini
    attrib +r "%~dp0."
  )
  echo  Made an "Ironclad Duel" shortcut here and on your Desktop - use that from now on.
)
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed.
  echo  Download the LTS version from https://nodejs.org , install it,
  echo  then double-click this file again.
  echo.
  start https://nodejs.org
  pause
  exit /b 1
)
if not exist node_modules\ws (
  echo Installing the server's one dependency...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo  npm install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo.
echo  Starting Ironclad Duel. Leave this window open while you play.
echo  Your browser will open http://localhost:8080
echo.
start "" http://localhost:8080
node server.js
echo.
echo  The server stopped.
pause
