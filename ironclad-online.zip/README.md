# Ironclad Duel: online duels

This folder runs the game with live two-player duels over the internet.
One of you hosts the fight; the other joins with a four-letter room code.

The server does very little. It shows the game page and passes messages between the two players in a room.

## Option 1: free hosting on Render (easiest, works anywhere)

1. Make a free account at https://render.com and a free account at https://github.com.
2. On GitHub, create a new repository and upload everything in this folder
   (`server.js`, `package.json`, `README.md` and the `public` folder).
3. On Render, choose **New → Web Service** and pick that repository.
4. Use these settings:
   - Runtime: **Node**
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: **Free**
5. Click **Create Web Service** and wait for it to say *Live*.
6. Open the address Render gives you (something like `https://ironclad-duel.onrender.com`).
   Send the same address to your opponent.

Free Render servers fall asleep after about 15 minutes with no visitors.
The first visit after that takes up to a minute to wake it.

## Option 2: run it on your own computer

You need Node.js 18 or newer from https://nodejs.org.

**On Windows:** unzip the folder, then double-click `ironclad.bat`. It installs what it needs, starts the server and opens the game in your browser. Keep that black window open while you play.

**Important:** don't open `public/index.html` directly. The online lobby only works when the game is opened from the server's address (`http://localhost:8080` or your Render address).

Or from a terminal:

```
cd ironclad-online
npm install
npm start
```

Then open http://localhost:8080.

- **Same house / same Wi-Fi:** your opponent opens `http://YOUR-PC-IP:8080`
  (find your IP with `ipconfig` on Windows). Allow Node through the Windows firewall when it asks.
- **Over the internet from your PC:** forward port 8080 on your router to your PC,
  then your opponent opens `http://YOUR-PUBLIC-IP:8080`. Render (option 1) is usually easier.

## Playing

1. Both players open the game and choose **Fight online** on the main menu.
2. One player clicks **Create room** and reads out the four-letter code.
3. The other types the code and clicks **Join room**. The duel starts at once.
4. Each of you fights in your own look and armoury kit (from that browser's campaign save).
5. After a bout, the host clicks **Rematch**; either player can **Leave**.

Controls are the same as the normal game: the cursor is your sword point,
A/D walk, Space or the wheel steps back, W/S raise and lower a shield,
right button for a reverse grip, double-click to kick.

## How it works

The host's game runs the real fight. The guest sends its cursor and keys about 60 times a second
and gets both knights back about 30 times a second, along with every spark, sound and message.
The guest's own sword is drawn immediately from its own mouse so it feels responsive; everything
else (hits, damage, the other knight) arrives a fraction of a second later. Players in the same
country should find it smooth; very long distances will make blocks and parries feel slightly late.

## Updating the game

Replace `public/index.html` with a newer copy of the game. On your own computer the server picks
it up straight away; on Render, upload the new file to GitHub and Render redeploys it.


## Icon
Windows can't put a custom icon on a .bat file, so the first time you run `ironclad.bat` it creates an **Ironclad Duel** shortcut (with the shield-and-swords icon) in this folder and on your Desktop, and gives the folder itself the icon. Launch the game from that shortcut afterwards.
